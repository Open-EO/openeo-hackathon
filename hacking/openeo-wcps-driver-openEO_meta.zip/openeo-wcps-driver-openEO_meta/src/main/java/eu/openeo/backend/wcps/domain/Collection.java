package eu.openeo.backend.wcps.domain;

public class Collection {

	private String name;

	public Collection(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

}
